CREATE USER 'admin_user'@'localhost' IDENTIFIED BY 'abc123';
GRANT ALL PRIVILEGES ON my_db.* TO 'admin_user'@'localhost';
FLUSH PRIVILEGES;

SET FOREIGN_KEY_CHECKS=0;

-- ----------------------------
-- Table structure for user
-- ----------------------------
DROP TABLE IF EXISTS `user`;
CREATE TABLE `user` (
  `UserID` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `UserName` varchar(255) DEFAULT NULL,
  `Email` varchar(255) DEFAULT NULL,
  `Password` varchar(255) DEFAULT NULL,
  `VerifyCode` varchar(255) DEFAULT NULL,
  `Status` varchar(255) DEFAULT '',
  PRIMARY KEY (`UserID`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8;
SET FOREIGN_KEY_CHECKS=0;
-- ----------------------------
-- Records of user
-- ----------------------------
INSERT INTO `user` (`UserName`, `Email`, `Password`, `VerifyCode`, `Status`) VALUES
('Nguyen Van A', 'a@gmail.com', '123456', 'ABC123', 'active'),
('Tran Thi B', 'b@gmail.com', '654321', 'DEF456', 'inactive'),
('Le Van C', 'c@gmail.com', 'password', 'GHI789', 'active'),
('Pham Thi D', 'd@gmail.com', 'mypassword', 'JKL012', 'pending');

-- ----------------------------
-- Table structure for category
-- ----------------------------
DROP TABLE IF EXISTS `category`;
CREATE TABLE `category` (
  `CategoryID` int unsigned NOT NULL AUTO_INCREMENT,
  `CategoryName` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`CategoryID`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- ----------------------------
-- Records of category
-- ----------------------------
INSERT INTO `category` VALUES ('1', 'Laptop');
INSERT INTO `category` VALUES ('2', 'Case');
INSERT INTO `category` VALUES ('3', 'Monitor');
INSERT INTO `category` VALUES ('4', 'Other');
INSERT INTO `category` VALUES ('7', 'new');

-- ----------------------------
-- Table structure for product
-- ----------------------------
DROP TABLE IF EXISTS `product`;
CREATE TABLE `product` (
  `ProductID` int unsigned NOT NULL AUTO_INCREMENT,
  `ProductName` varchar(255) DEFAULT NULL,
  `Description` varchar(255) DEFAULT NULL,
  `CategoryID` int unsigned NOT NULL,
  `Image` longblob,
  `Status` char(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`ProductID`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
-- ----------------------------
-- Records of product
-- ----------------------------
INSERT INTO `product` (`ProductName`, `Description`, `CategoryID`, `Image`, `Status`) VALUES
('Laptop Dell XPS 13', 'Laptop cao cấp cho doanh nhân', 1, NULL, '1'),
('Case Coolermaster', 'Case đẹp có LED RGB', 2, NULL, '1'),
('Màn hình LG 27"', 'Màn hình Full HD 27 inch', 3, NULL, '1'),
('Chuột không dây Logitech', 'Phụ kiện chuột không dây', 4, NULL, '1'),
('Laptop Asus TUF Gaming', 'Laptop chơi game cấu hình cao', 1, NULL, '0');
